<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Bid for Auction #<?php echo e($auction->id); ?></div>

                    <div class="card-body">
                        <form method="POST" action="/client/auction-bid/<?php echo e($auction->id); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-2">Amount</div>
                                <div class="col-md-4">
                                    <input required class="form-control" name="amount" step="any" type="number">
                                </div>

                            </div>
                            <hr>
                            <hr>
                            <div class="row">
                                <div class="col-md-2">
                                    <button class="btn btn-success">
                                        <i class="fa fa-check"></i>
                                        Bid
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

                <div class="card">
                    <div class="card-header">All bids</div>
                    <div class="card-body">
                        <div class="row">
                            <div  class="col-md-12 table-responsive table-stats order-table ov-h">
                                <table class="table table-borderless">
                                    <thead>
                                    <tr>
                                        <th class="serial">#</th>
                                        <th>Bid by</th>
                                        <th>Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $auction->bids()->orderBy('amount','DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="serial"><?php echo e($key+1); ?></td>
                                            <td><?php echo e($bid->user->name); ?></td>
                                            <td>$<?php echo e($bid->amount); ?></td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    | Auctions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        jQuery('#auctions').addClass('active')
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client_new', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>