<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php echo $__env->make('includes.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Auctions
                        <select class="form-control-sm" name="type" id="type">
                            <option <?php echo e($type==1?'selected':''); ?> value="1">All</option>
                            <option  <?php echo e($type==2?'selected':''); ?> value="2">New</option>
                            <option <?php echo e($type==3?'selected':''); ?> value="3">Closed</option>
                        </select>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <?php if(sizeof($auctions)>0): ?>
                                <div  class="col-md-12 table-responsive table-stats order-table ov-h">

                                    <table class="table table-borderless">
                                        <thead>
                                        <tr>
                                            <th class="serial">#</th>
                                            <th></th>
                                            <th>Title</th>
                                            <th>Vehicle</th>
                                            <th>Start</th>
                                            <th>End</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="serial"><?php echo e($key+1); ?></td>
                                                <td><img  style="width: 100px; height: 50px;" src="<?php echo e($auction->getThumbnail()); ?>"></td>
                                                <td><a class="btn-link" href="/admin/auction/<?php echo e($auction->id); ?>"><?php echo e($auction->title); ?></a></td>
                                                <td><?php echo e($auction->vehicle); ?></td>
                                                <td><?php echo e($auction->start); ?></td>
                                                <td><?php echo e($auction->end); ?></td>
                                                <td><?php if($auction->status==1): ?>
                                                        <a href="#" onclick="clicked('<?php echo e($auction->id); ?>')" class="btn btn-danger btn-labeled fa fa-trash"> Delete</a>
                                                        <form style="display: none;" id="del<?php echo e($auction->id); ?>" action="/admin/auction/<?php echo e($auction->id); ?>" method="POST">
                                                            <input name="_method" type="hidden" value="DELETE">
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">No Auctions</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    | Auctions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        jQuery('#auctions').addClass('active')
        jQuery(document).ready(function () {
            jQuery('#type').change(function () {
                if(jQuery(this).val()==1)
                    window.location='/admin/auction';
                else if(jQuery(this).val()==2)
                    window.location='/admin/auction?type=new';
                else if(jQuery(this).val()==3)
                    window.location='/admin/auction?type=closed';
            }) ;

        });
        function clicked(id){

            if(confirm("Are You Sure ?")){
                document.getElementById('del'+id).submit();
            }
            else{
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>