<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-2">
            <a class="btn btn-primary" href="/admin/auction/create"><i class="fa fa-plus"></i> Add Auction</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    | Dashboard
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>