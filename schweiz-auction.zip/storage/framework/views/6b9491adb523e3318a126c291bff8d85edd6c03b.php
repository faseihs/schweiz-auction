<?php $__env->startSection('content'); ?>
    <hr>
    <div class="container">
        <?php echo $__env->make('includes.flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">My Bids
                        <select class="form-control-sm" name="type" id="type">
                            <option <?php echo e($type==1?'selected':''); ?> value="1">All</option>
                            <option  <?php echo e($type==2?'selected':''); ?> value="2">Won</option>
                            <option <?php echo e($type==3?'selected':''); ?> value="3">Lost</option>
                        </select>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div  class="col-md-12 table-responsive table-stats order-table ov-h">
                                <table class="table table-borderless">
                                    <thead>
                                    <tr>
                                        <th class="serial">#</th>
                                        <th>Title</th>
                                        <th>Vehicle</th>
                                        <th>Start</th>
                                        <th>End</th>
                                        <th>Amount</th>
                                        <th>Won</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="serial"><?php echo e($key+1); ?></td>
                                            <td><a class="btn-link" href="/client/auction/<?php echo e($bid->auction->id); ?>"><?php echo e($bid->auction->title); ?></a></td>
                                            <td><?php echo e($bid->auction->vehicle); ?></td>
                                            <td><?php echo e($bid->auction->start); ?></td>
                                            <td><?php echo e($bid->auction->end); ?></td>
                                            <td>$<?php echo e($bid->amount); ?></td>
                                            <td><?php echo e($bid->winner==1?'Yes':'No'); ?></td>
                                            <td>
                                                <?php if($bid->auction->status==1): ?>
                                                <a href="#" onclick="clicked(<?php echo e($bid->id); ?>)" class="btn btn-sm btn-danger btn-labeled fa fa-trash"> Delete</a>



                                                <form style="display: none;" id="del<?php echo e($bid->id); ?>" action="/client/bid/<?php echo e($bid->id); ?>" method="POST">
                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
    | Auctions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {
            $('#type').change(function () {
                if($(this).val()==1)
                    window.location='/client/bid';
                else if($(this).val()==2)
                    window.location='/client/bid?type=won';
                else if($(this).val()==3)
                    window.location='/client/bid?type=lost';
            }) ;
        });
        function clicked(id){
            if(confirm("Are You Sure ?")){
                document.getElementById('del'+id).submit();
            }
            else{
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client_new', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>