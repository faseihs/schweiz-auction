<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-4 col-sm-12">
            <div class="card">
                <div class="card-header">Auction Details</div>
                <div class="card-body">
                    <div class="row">
                        <div style="font-size: 13px;" class="col-md-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <th></th>
                                    <th></th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Title</td>
                                        <td><?php echo e($auction->title); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Vehicle</td>
                                        <td><?php echo e(ucfirst($auction->vehicle)); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Start</td>
                                        <td><?php echo e($auction->start); ?></td>
                                    </tr>
                                    <tr>
                                        <td>End</td>
                                        <td><?php echo e($auction->end); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Created</td>
                                        <td><?php echo e($auction->created_at); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Bids</td>
                                        <td><?php echo e(sizeof($auction->bids)); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Starts in</td>
                                        <td class="countdown-container" id="start"></td>
                                    </tr>
                                    <tr>
                                        <td>Ends in</td>
                                        <td id="end"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <hr>
                    <hr>
                    <div class="row">
                        <div class="col-md-2">
                            <a class="btn btn-success btn-sm" href="/client/auction-bid/<?php echo e($auction->id); ?>">
                                <i class="fa fa-check"></i>
                                Bid
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12">
            <div id="slider" class="flexslider">
                <ul class="slides">
                    <?php $__currentLoopData = $auction->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img style="max-height: 400px" class="img-responsive" src="<?php echo e($file->getImage()); ?>" />
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- items mirrored twice, total of 12 -->
                </ul>
            </div>


        </div>

    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Vehicle Details</div>
                <div class="card-body">
                    <div class="row">
                        <div style="font-size: 13px;" class="col-md-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <th></th>
                                    <th></th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Mileage</td>
                                        <td><?php echo e($auction->Vehicle->mileage); ?></td>
                                    </tr>
                                    <tr>
                                        <td>1st Reg</td>
                                        <td><?php echo e($auction->Vehicle->registration); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Wheeldrive</td>
                                        <td><?php echo e($auction->Vehicle->wheeldrive); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Gear</td>
                                        <td><?php echo e($auction->Vehicle->gear); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Fuel</td>
                                        <td><?php echo e($auction->Vehicle->fuel); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Displacement</td>
                                        <td><?php echo e($auction->Vehicle->displacement); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Body</td>
                                        <td><?php echo e($auction->Vehicle->body); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Interior</td>
                                        <td><?php echo e($auction->Vehicle->interior); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Exterior Color</td>
                                        <td><?php echo e($auction->Vehicle->exterior_color); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Seats</td>
                                        <td><?php echo e($auction->Vehicle->seats); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Transported By</td>
                                        <td><?php echo e($auction->Vehicle->transported_by); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <hr>
                    <hr>



                </div>
            </div>

        </div>
        <div style="font-size: 13px;" class="col-md-8">
            <div class="card">
                <div class="card-header">Further Descriptions</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 font-weight-bold">Serial Equipment</div>
                        <div class="col-md-9"><?php echo e($auction->Vehicle->serial_equipment); ?></div>
                    </div>
                    <hr>
                    <hr>
                    <div class="row">
                        <div class="col-md-3 font-weight-bold">Special Equipment</div>
                        <div class="col-md-9"><?php echo e($auction->Vehicle->special_equipment); ?></div>
                    </div>
                    <hr>
                    <hr>
                    <div class="row">
                        <div class="col-md-3 font-weight-bold">Financial Services</div>
                        <div class="col-md-9"><?php echo e($auction->Vehicle->financial_services); ?></div>
                    </div>
                    <hr>
                    <hr>
                    <div class="row">

                        <h5 class="col-md-12 font-weight-bold">Vehicle Description</h5>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = explode('_',$auction->Vehicle->vehicle_description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(explode('-',$v)[0]); ?></td>
                                        <td><?php echo e(explode('-',$v)[1]); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                    <hr>
                    <hr>

                    <div class="row">

                        <h5 class="col-md-12 font-weight-bold">Conditions</h5>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="list-group">
                                <?php $__currentLoopData = explode('-',$auction->Vehicle->condition); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item"> <?php echo e($c); ?></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div style="font-size: 13px;" class="col-md-12">
            <div class="card">
                <div class="card-header">All bids</div>
                <div class="card-body">
                    <div class="row">
                        <div  class="col-md-12 table-responsive table-stats order-table ov-h">
                            <table class="table table-striped table-borderless">
                                <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>Bid by</th>
                                    <th>Amount</th>
                                    <th>Won</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $auction->bids()->orderBy('amount','DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="serial"><?php echo e($key+1); ?></td>
                                        <td><?php echo e($bid->user->name); ?></td>
                                        <td>$<?php echo e($bid->amount); ?></td>
                                        <td><?php echo e($bid->winner==1?'Yes':'No'); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    | Auction : <?php echo e($auction->id); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.countdown.min.js')); ?>"></script>
    <script>
        jQuery(document).ready(function () {
            jQuery('auctions').addClass('active');
            jQuery('body').addClass('open');
            jQuery("#start")
                .countdown("<?php echo e($auction->start); ?>", function(event) {
                    jQuery(this).text(
                        event.strftime('%D days %H:%M:%S')
                    );
                });
            jQuery("#end")
                .countdown("<?php echo e($auction->end); ?>", function(event) {
                    jQuery(this).text(
                        event.strftime('%D days %H:%M:%S')
                    );
                });
        });

        jQuery('#carousel').flexslider({
            animation: "slide",
            /* controlNav: false,
             animationLoop: false,
             slideshow: false,
             itemWidth: 210,
             itemMargin: 5,
             asNavFor: '#slider'*/
        });

        jQuery('#slider').flexslider({
            animation: "slide",
            controlNav: false,
            animationLoop: false,
            slideshow: false,
            sync: "#carousel"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/flexslider.css')); ?>">
    <style>
        @font-face {
            font-family: 'flexslider-icon';
            src: url('<?php echo e(asset("fonts/flexslider-icon.eot")); ?>');
            src: url('<?php echo e(asset("fonts/flexslider-icon.eot?#iefix")); ?>') format('embedded-opentype'), url('<?php echo e(asset("fonts/flexslider-icon.woff")); ?>') format('woff'), url('<?php echo e(asset("fonts/flexslider-icon.ttf")); ?>') format('truetype'), url('<?php echo e(asset("fonts/flexslider-icon.svg#flexslider-icon")); ?>') format('svg');
            font-weight: normal;
            font-style: normal;
        }
    </style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client_new', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>