@extends('layouts.admin')

@section('content')
    <div class="row">
        <div class="col-md-2">
            <a class="btn btn-primary" href="/admin/auction/create"><i class="fa fa-plus"></i> Add Auction</a>
        </div>
    </div>
@endsection


@section('title')
    | Dashboard
@endsection
