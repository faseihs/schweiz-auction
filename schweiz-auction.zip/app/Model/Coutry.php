<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Coutry extends Model
{
    //
}
